title: ES6 创建类和对象
date: '2019-09-28 09:56:23'
updated: '2019-09-28 09:56:23'
tags: [ES6]
permalink: /articles/2019/09/28/1569635783690.html
---
![image.png](https://img.hacpai.com/file/2019/09/image-6e39cd41.png)

