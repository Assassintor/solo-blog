title: 世界，你好！Welcome!!
date: '2019-09-23 09:50:06'
updated: '2019-09-23 09:55:19'
tags: [Solo]
permalink: /hello-solo
---
![](https://img.hacpai.com/bing/20190909.jpg?imageView2/1/w/1280/h/720/interlace/1/q/100) 

Solo 博客系统已经初始化完毕，可在管理后台 - 工具 - 偏好设定中调整更多细节设置。如果需要导入已有博客文章，请参考文档 [Hexo/Jekyll/Markdown 文件导入](https://hacpai.com/article/1498490209748)。

对了，出于安全考虑请尽快完成如下操作：

1. 使用 GitHub 账号登录[社区](https://hacpai.com)
2. 在社区[个人设置 - B3](https://hacpai.com/settings/b3) 中更新 B3 Key
3. 在 Solo 管理后台 - 工具 - 用户管理中也进行同样的 B3 Key 更新

另外，Solo 会每天自动导出你的博客文章到 GitHub 仓库（[示例](https://github.com/88250/solo-blog)）：

1. 有机会让更多人看到你的文章
2. 自动备份文章数据

该功能默认是开启的，如果不需要请到管理后台 - 工具 - 偏好设定 - 参数设置中关闭。开启时会自动创建/更新 `solo-blog` 仓库，请注意你没有该同名仓库以免数据被覆盖。

最后，如果你觉得 Solo 很赞，请到[项目主页](https://github.com/b3log/solo)给颗星鼓励一下 :heart:
