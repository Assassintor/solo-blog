title: Bower和Npm的区别
date: '2019-09-25 12:30:17'
updated: '2019-09-25 12:36:01'
tags: [bower, nodeJs, npm]
permalink: /articles/2019/09/25/1569385817595.html
---
>[https://bower.io/](https://bower.io/)

>[https://github.com/bower/bower](https://github.com/bower/bower)

>[http://nodejs.cn/](http://nodejs.cn/)

>[https://www.npmjs.com/get-npm](https://www.npmjs.com/get-npm)

>bower 和 npm 的区别：  

npm 是伴随Node.js 出现的一个包管理器，最开始只能支持 Node.js 的模块管理，但是后来， npm官网经过一次改版，打出的口号是javascript 的包管理器，所以，其已经不在局限于是Node.js 的模块管理了，已经通用到了所有 js 的包管理工具了，可以说，前后通吃了。  
bower 的话，从一开始，就是专门为前端表现设计的包管理器，一切全部为前端考虑的。npm 和bower 的最大区别，就是 npm 支持嵌套地依赖管理，而 bower只能支持扁平的依赖（嵌套的依赖，由程序员自己解决）。  
  
>现在不建议使用bower了。官方已经停止维护，建议直接使用npm就可以了。
