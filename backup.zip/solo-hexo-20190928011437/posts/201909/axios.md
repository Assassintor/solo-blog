title: axios
date: '2019-09-25 22:50:29'
updated: '2019-09-25 22:50:29'
tags: [axios]
permalink: /articles/2019/09/25/1569423029640.html
---
>github ：[https://github.com/axios/axios](https://github.com/axios/axios)  
  
>官网 ：[http://www.axios-js.com/](http://www.axios-js.com/)  
  
>axios 文档：[http://www.axios-js.com/zh-cn/docs/](http://www.axios-js.com/zh-cn/docs/)  
  
## 特性  
  
* 从浏览器中创建 [XMLHttpRequests](https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest)  
* 从 node.js 创建 [http](http://nodejs.org/api/http.html) 请求  
* 支持 [Promise](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise) API  
* 拦截请求和响应  
* 转换请求数据和响应数据  
* 取消请求  
* 自动转换 JSON 数据  
* 客户端支持防御 [XSRF](http://en.wikipedia.org/wiki/Cross-site_request_forgery)
