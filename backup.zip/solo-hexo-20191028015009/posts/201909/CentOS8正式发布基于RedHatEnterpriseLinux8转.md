title: CentOS 8 正式发布，基于Red Hat Enterprise Linux 8 （转)
date: '2019-09-25 22:11:53'
updated: '2019-09-27 17:26:39'
tags: [Centos8]
permalink: /articles/2019/09/25/1569420713857.html
---
[CentOS](https://www.linuxidc.com/topicnews.aspx?tid=14 "CentOS")项目是对[Red Hat](https://www.linuxidc.com/topicnews.aspx?tid=10 "Red Hat") Enterprise Linux的100％兼容的重建，完全符合Red Hat的重新发布要求，并发布了一个新版本：CentOS 8.0.1905，适用于所有受支持的体系结构。

紧随CentOS Linux 7.7发行版之后，CentOS Linux 8现已正式发布，新版本基于Red Hat Enterprise Linux 8.0源，这意味着它具有混合云时代的所有强大的新特性和增强功能。

![CentOS 8 正式发布，基于Red Hat Enterprise Linux 8](https://www.linuxidc.com/upload/2019_09/19092506398584.png)

重点包括对应用程序Streams的支持，Streams由快速更新的框架，编程语言和开发人员工具组成，并经常更新，系统管理员可以更轻松地自动执行复杂的任务，以及对OpenSSL 1.1.1和TLS 1.3加密标准的内置支持。

CentOS Linux 8还提供了对ARM和POWER体系结构的支持，基于DNF的YUM软件包管理器，默认情况下为[Python](https://www.linuxidc.com/topicnews.aspx?tid=17 "Python") 3，更新的版本控制系统（包括Git 2.18，Mercurial 4.8和Subversion 1.10）的改进，对GNOME 3.28桌面环境的支持。以及Anaconda安装程序中的LUKS2磁盘加密支持。

CentOS Linux 8发行版的其他值得注意的功能是BPF编译器集合（BCC），用于创建有效的内核跟踪和操作程序的新工具，内核中扩展的伯克利包过滤（eBPF）功能以及用于创建自定义系统映像的Image Builder工具。

![CentOS 8 正式发布，基于Red Hat Enterprise Linux 8](https://www.linuxidc.com/upload/2019_09/19092506395659.png)

**更新的组件**

在底层，CentOS Linux 8附带了许多更新的组件，其中我们可以提到PHP 7.2，Ruby 2.5，Perl 5.26，SWIG 3.0，MariaDB 10.3，MySQL 8.0，PostgreSQL 10，PostgreSQL 9.6，Redis 5，Apache 2.4，nginx 1.14 ，Squid 4.4和Varnish Cache 6.0。

您可以立即通过[官方网站](https://centos.org/download/)下载用于64位（x86_64）体系结构的CentOS Linux 8。 CentOS Linux 8也可以从以下链接下载用于AArch64（ARM64）和PPC64le（PowerPC 64位Little Endian）架构。同样在今天，出人意料的是Red Hat也宣布发布CentOS Stream，因为它们是面向开发人员和早期采用者的新的前瞻性滚动发行版。

![CentOS 8 正式发布，基于Red Hat Enterprise Linux 8](https://www.linuxidc.com/upload/2019_09/19092506439579.png)

[CentOS-8](http://isoredirect.centos.org/centos/8/isos/x86_64/CentOS-8-x86_64-1905-dvd1.iso)[-x86_64-1905-dvd1.iso](http://isoredirect.centos.org/centos/8/isos/x86_64/CentOS-8-x86_64-1905-dvd1.iso) (6,805MB, [SHA256](http://centos.mirror.iweb.ca/8.0.1905/isos/x86_64/CHECKSUM), [signature](http://centos.mirror.iweb.ca/8.0.1905/isos/x86_64/CHECKSUM.asc), [torrent](http://centos.mirror.iweb.ca/8.0.1905/isos/x86_64/CentOS-8-x86_64-1905-dvd1.torrent)), [CentOS-8-x86_64-1905-boot.iso](http://centos.mirror.iweb.ca/8.0.1905/isos/x86_64/CentOS-8-x86_64-1905-boot.iso) (534MB, [SHA256](http://centos.mirror.iweb.ca/8.0.1905/isos/x86_64/CHECKSUM), [signature](http://centos.mirror.iweb.ca/8.0.1905/isos/x86_64/CHECKSUM.asc), [torrent](http://centos.mirror.iweb.ca/8.0.1905/isos/x86_64/CentOS-8-x86_64-1905-boot.torrent)), [CentOS-Stream-x86_64-dvd1.iso](http://isoredirect.centos.org/centos/8-stream/isos/x86_64/CentOS-Stream-x86_64-dvd1.iso) (8,175MB, [SHA256](http://mirror.datto.com/CentOS/8-stream/isos/x86_64/CHECKSUM)), [CentOS-Stream-x86_64-boot.iso](http://mirror.datto.com/CentOS/8-stream/isos/x86_64/CentOS-Stream-x86_64-boot.iso) (533MB, [SHA256](http://mirror.datto.com/CentOS/8-stream/isos/x86_64/CHECKSUM))。

更多CentOS相关信息见[CentOS](https://www.linuxidc.com/topicnews.aspx?tid=14) 专题页面 [https://www.linuxidc.com/topicnews.aspx?tid=14](https://www.linuxidc.com/topicnews.aspx?tid=14 "CentOS")

Linux公社的RSS地址：[https://www.linuxidc.com/rssFeed.aspx](https://www.linuxidc.com/rssFeed.aspx)

**原文地址**：[https://www.linuxidc.com/Linux/2019-09/160804.htm](https://www.linuxidc.com/Linux/2019-09/160804.htm)
