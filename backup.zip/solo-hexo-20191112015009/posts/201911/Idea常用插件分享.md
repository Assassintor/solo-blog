title: Idea常用插件分享
date: '2019-11-09 00:50:45'
updated: '2019-11-09 00:50:45'
tags: [Idea, Idea插件]
permalink: /articles/2019/11/09/1573231845555.html
---
## 常用插件  
  
### Background Image Plus   
设置背景  
使用方式  
![image.png](https://img.hacpai.com/file/2019/11/image-47755e58.png)  
  
### Material Theme UI  
  
这是一款主题插件，可以让你的ide的图标变漂亮，配色搭配的很到位，还可以切换不同的颜色，甚至可以自定义颜色。默认的配色就很漂亮了，如果需要修改配色，可以在工具栏中Tools->Material Theme然后修改配色等。  
  
### activate-power-mode / Power mode  
  
这是一款让你在编码的时候，整个屏幕都为之颤抖的插件。  
  
### Nyan progress bar  
  
这是一个将你idea中的所有的进度条都变成萌新动画的小插件。  
  
### Mybatis Log Plugin  
Mybatis现在是java中操作数据库的首选，在开发的时候，我们都会把Mybatis的脚本直接输出在console中，  
但是默认的情况下，输出的脚本不是一个可以直接执行的。  
  
如果我们想直接执行，还需要在手动转化一下，比较麻烦。   
MyBatis Log Plugin 这款插件是直接将Mybatis执行的sql脚本显示出来，无需处理，可以直接复制出来执行的 。  
  
Tools -- >  Mybatis Log Plugin  打开其日志框，注意其转换的SQL不是输出到IDE的控制台!!  
  
### Grep Console  
log日志高亮,由于Intellij idea不支持显示ascii颜色，grep-console插件能很好的解决这个问题， 可以设置不同级别log的字体颜色和背景色.  
  
### CodeGlance  
CodeGlance是一款代码编辑区缩略图插件，可以快速定位代码，使用起来比拖动滚动条方便多了  
  
### IDEA Restart  
  
 IDEA没有重启的选项，这个工具就是来弥补这个功能，可以在File-->Restart 重启，也可以使用快捷键  CTRL + ALT + R  
  
### RestfulToolkit  
  
一套 RESTful 服务开发辅助工具集。  
  
1.根据 URL 直接跳转到对应的方法定义 ( or Ctrl Alt N );  
2.提供了一个 Services tree 的显示窗口;  
3.一个简单的 http 请求工具;  
4.在请求方法上添加了有用功能: 复制生成 URL;,复制方法参数...  
5.其他功能: java 类上添加 Convert to JSON 功能，格式化 json 数据 ( Windows: Ctrl + Enter; Mac: Command + Enter )。  
 安装后，右侧会有RestServices侧边栏，点击打开  
  
全局快捷搜索快捷键：`Ctrl  \ `  
  
### Maven Helper   
  
分析依赖冲突插件  
  
此插件可用来方便显示maven的依赖树，在没有此插件时，如果想看maven的依赖树需要输入命令行： mvn dependency:tree  才可查看依赖。如果想看是否有依赖包冲突的话也需要输入命令行等等的操作。而如果安装Maven Helper插件就可免去命令行困扰。通过界面即可操作完成。  
  
使用方式：  
  
打开项目中的pom文件，在底部会显示一个“Dependency Analyzer”,  
  
>可进行相应操作：  
>* Conflicts（查看冲突）  
>* All Dependencies as List（列表形式查看所有依赖）  
>* All Dependencies as Tree（树形式查看所有依赖）  
>* 搜索功能  
  
### **JRebel**  
热部署插件，让你在修改完代码后，不用再重新启动，很实用！但是，不是免费的。  
  
### **Rainbow Brackets**  
彩虹颜色的括号  在黑色主题下看的比较清楚舒服，白色主题下看的很不明显，看自己选择了，除了看着舒服，也有助于  
  
帮助区分前后括号对应关系。  
  
### aiXcode  
  
 推荐使用！！！真正的提高编码效率！  
AI智能编程插件。aiXcoder主要两个功能：代码自动补全和相似代码智能推荐。程序员写代码时，AI引擎会进行预测并自动补全后续代码。同时，aiXcoder会基于程序员输入的代码，从后台规范代码库中调用相似的代码，在分屏中显示以供程序员参考。  
  
安装方式见参考: [IntelliJ IDEA 安装使用 aiXcoder 智能编程助手](https://blog.csdn.net/weixin_41846320/article/details/101220894)  
  
### Mybatis plugin  
  
可以在mapper接口中和mapper的xml文件中来回跳转，就想接口跳到实现类那样简单。  
  
### MyBatis Log Plugin  
  
Mybatis现在是java中操作数据库的首选，在开发的时候，我们都会把Mybatis的脚本直接输出在console中，但是默认的情况下，输出的脚本不是一个可以直接执行的。  
  
### GenerateAllSetter  
  
一键调用一个对象的所有set方法并且赋予默认值 在对象字段多的时候非常方便，在做项目时，每层都有各自的实体对象需要相互转换，但是考虑BeanUtil.copyProperties()等这些工具的弊端，有些地方就需要手动的赋值时，有这个插件就会很方便，创建完对象后在变量名上面按Alt+Enter就会出来 generate all setter选项。  
  
### codehelper.generator  
  
可以让你在创建一个对象并赋值的时候，快速的生成代码，不需要一个一个属性的向里面set,根据new关键字，自动生成掉用set方法的代码，还可以一键填入默认值。  
  
GenAllSetter 特性  
  
* 在Java方法中, 根据 `new` 关键词, 为Java Bean 生成所有Setter方法。  
* 按GenAllSetter键两次, 会为Setter方法生成默认值。  
* 可在`Intellij Idea`中为`GenAllSetter`设置快捷键。  
* 如何使用:  
    
 * 将光标移动到 `new` 语句的下一行。  
 * 点击主菜单Tools-> Codehelper-> GenAllSetter, 或者按下`GenAllSetter`快捷键。  
    
 GenDaoCode 特性  
    
 * 根据Pojo 文件一键生成 Dao，Service，Xml，Sql文件。  
    
 * Pojo文件更新后一键更新对应的Sql和mybatis xml文件。  
    
 * 提供insert，insertList，update，select，delete五种方法。  
    
 * 能够批量生成多个Pojo的对应的文件。  
    
 * 自动将pojo的注释添加到对应的Sql文件的注释中。  
    
 * 丰富的配置，如果没有配置文件，则会使用默认配置。  
    
 * 可以在Intellij Idea中快捷键配置中配置快捷键。  
    
 * 目前支持MySQL + Java，后续会支持更多的DB。  
    
 * 如果喜欢我们的插件，非常感谢您的分享。  
    
    
 GenDaoCode 使用方法  
    
 * 主菜单Tools-> Codehelper-> GenDaoCode 按键便可生成代码。  
    
 * 方法一：点击GenDaoCode，然后根据提示框输入Pojo名字，多个Pojo以 | 分隔。  
    
 * Codehelper Generator会根据默认配置为您生成代码。  
    
 * 方法二：在工程目录下添加文件名为codehelper.properties的文件。  
    
 * 点击GenDaoCode，Codehelper Generator会根据您的配置文件为您生成代码  
  
### 阿里代码规约检测：Alibaba Java Coding Guidelines  
### 快捷键提示工具：Key promoter X  
### 代码注解插件： Lombok  
### 代码生成工具：CodeMaker  
### 代码质量检查工具：SonarLint  
### 单元测试测试生成工具：JUnitGenerator  
### Mybatis 工具：Free Mybatis plugin  
### JSON转领域对象工具：GsonFormat  
一键根据json生成java类  
### 字符串工具：String Manipulation  
### 生成对象set方法：GenerateAllSetter  
### Redis可视化：Iedis  
### K8s工具：Kubernetes  
### 中英文翻译工具：Translation  /  ECtranslation  
  
### Key promoter  
  
Key promoter这款插件适合新手使用。当你点击鼠标一个功能的时候，可以提示你这个功能快捷键是什么。这是一个非常有用的功能，很快就可以熟悉软件的快捷功能了。 如果有快捷键的，会直接显示快捷键  
  
![null](https://ask.qcloudimg.com/http-save/yehe-2899014/qko3siuu2m.png?imageView2/2/w/1620)  
  
没有快捷键的，会提示你去设置快捷键。比如我连续3次用鼠标创建TypeScript类，第三次就会出现提示  
  
### findBugs  
  
找到那些被你隐藏的bug  
  
### String Manipulation  
  
强大的字符串转换工具。使用快捷键，Alt+m。  
  
切换样式（camelCase, hyphen-lowercase, HYPHEN-UPPERCASE, snake_case, SCREAMING_SNAKE_CASE, dot.case, words lowercase, Words Capitalized, PascalCase）  
  
转换为SCREAMING_SNAKE_CASE (或转换为camelCase)  
  
转换为 snake_case (或转换为camelCase)  
  
转换为dot.case (或转换为camelCase)  
  
转换为hyphen-case (或转换为camelCase)  
  
转换为hyphen-case (或转换为snake_case)  
  
转换为camelCase (或转换为Words)  
  
转换为camelCase (或转换为lowercase words)  
  
转换为PascalCase (或转换为camelCase)  
  
选定文本大写  
  
样式反转  
  
### idea自带反编译工具 IdeaJad  
  
以前查看class文件形式的时候或者jar，都会使用一个外部反编译工具，这样操作明显不方便，使用此插件可以一直在idea中查看文件~  ps：其实Inteli Idea这个编译器已经自带了反编译功能，老夫~~~~~~  
  
选择class文件，右键 Decompile,完成反编译  
  
### **MyBatisCodeHelperPro**  
  
这个是一款比较实用的插件。需要付费。  
  
>提供Mapper接口与配置文件中对应SQL的导航.  
编辑XML文件时自动补全.  
根据Mapper接口, 使用快捷键生成xml文件及SQL标签.  
ResultMap中的property支持自动补全，支持级联(属性A.属性B.属性C).  
快捷键生成@Param注解.  
XML中编辑SQL时, 括号自动补全.  
XML中编辑SQL时, 支持参数自动补全(基于@Param注解识别参数).  
自动检查Mapper XML文件中ID冲突.  
自动检查Mapper XML文件中错误的属性值.  
支持Find Usage.  
支持重构从命名.  
支持别名.  
自动生成ResultMap属性.  
快捷键: Option + Enter(Mac) | Alt + Enter(Windows).  
  
安装成功最明显的标志就是~  有好多小鸟在飞~  
  
### **VisualVM Launcher**  
  
一般可用于在本地开发进行压力测试，性能测试之类的监控器，其他场景一般不推荐使用此模式启动，还会启动另外一个Visual vm窗口，这个窗口是JDK bin目录下的JvisualVM  
  
### CheckStyle-IDEA   
通过检查对代码编码格式，命名约定，Javadoc，类设计等方面进行代码规范和风格的检查，   
从而有效约束开发人员更好地遵循代码编写规范。软件安装成功之后，首先要设置规则。   
可以通过Preferences—>Other Settings —>CheckStyles   
进行设置，可以直接将文件添加进来，然后就可以对具体的文件进行检查了。  
  
### markdown   
安装这个插件之后，打开.md文件就可以通过一个支持md的视图查看和编辑内容。一般用于写README.md文件。但是这个插件我不太用，因为他对md语法支持的并不是很好。
