title: 修改MYSQL的默认连接时长
date: '2019-09-27 21:30:13'
updated: '2019-09-27 21:30:13'
tags: [MySQL]
permalink: /articles/2019/09/27/1569591013444.html
---
>修改MYSQL的默认连接时长

```
show global variables like 'wait_timeout';
```

>设置成10小时;

```
set global wait_timeout=36000;
```
