title: tomcat安装,JDK安装（windows10）
date: '2019-11-08 22:45:56'
updated: '2019-11-08 22:46:53'
tags: [Tomcat, Java, JDK]
permalink: /articles/2019/11/08/1573224356366.html
---
安装Tomcat前先安装JDK
## JDK安装
进入Oracle 官网下载JDK

>[JDK 8 链接通道 ](https://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
![image.png](https://img.hacpai.com/file/2019/11/image-72a40c51.png)
点击Accept ...同意后，选择你想要的版本即可下载

下载完成后，点击安装

### 环境变量配置
![image.png](https://img.hacpai.com/file/2019/11/image-8adfe510.png)

>在Path环境变量里面添加如下变量
![image.png](https://img.hacpai.com/file/2019/11/image-bdb3be55.png)

>`%JAVA_HOME%\bin` 
配置后使用javac等命令

>`%JAVA_HOME%\lib`
`%JAVA_HOME%\lib\tools.jar` 
不配置可能出现tomcat能正常启动，但是访问[http://localhost:8080](http://localhost:8080)失败

## Tomcat 安装

>[Tomcat 链接通道](https://tomcat.apache.org/download-80.cgi)
![image.png](https://img.hacpai.com/file/2019/11/image-11f946d9.png)
选择Zip文件下载

解压后即安装

### 环境变量配置

>添加环境变量
![image.png](https://img.hacpai.com/file/2019/11/image-dbae2cae.png)

>在Path环境变量里面添加如下变量
![image.png](https://img.hacpai.com/file/2019/11/image-c9a13549.png)
`%CATALINA_HOME%\bin`  添加此变量方便全局使用tomcat的脚步

进入cmd，输入`startup`即可启动tomcat

>弹出新的窗口，没有秒退即安装成功，在浏览器页面输入[http://localhost:8080](http://localhost:8080)访问到有猫的页面即成功
![image.png](https://img.hacpai.com/file/2019/11/image-128107f7.png)




