title: 基于Vue-Cli 脚手架的项目
date: '2019-09-25 11:42:40'
updated: '2019-09-25 12:19:22'
tags: [Vue-Cli, VueUi, Vue]
permalink: /articles/2019/09/25/1569382960429.html
---
>### [基于`@vue/cli` **3.x** 文档](https://cli.vuejs.org/zh/guide/#%E8%AF%A5%E7%B3%BB%E7%BB%9F%E7%9A%84%E7%BB%84%E4%BB%B6)

>### [基于`@vue/cli` **2.x** 文档](https://github.com/vuejs/vue-cli/tree/v2#vue-cli--)

>### [Vue](https://github.com/vuejs/vue)

>### [Iview-Admin 2.0](https://lison16.github.io/iview-admin-doc/#/%E5%85%A8%E5%B1%80%E9%85%8D%E7%BD%AE)

>#### [Iview-Admin 2.0 文档](https://lison16.github.io/iview-admin-doc/#/%E5%85%A8%E5%B1%80%E9%85%8D%E7%BD%AE)

>### [vue-element-admin](https://github.com/PanJiaChen/vue-element-admin)
vue-element-admin是用于管理界面的可用于生产环境的前端解决方案。它基于[vue](https://github.com/vuejs/vue)并使用UI Toolkit [element-ui](https://github.com/ElemeFE/element)。
>#### [vue-element-admin 文档](https://panjiachen.github.io/vue-element-admin-site/zh/)

>#### [vue-element-admin 展示](https://panjiachen.github.io/vue-element-admin/#/login?redirect=%2Fexcel%2Fupload-excel)

>### [vue-admin-template](https://github.com/PanJiaChen/vue-admin-template)


>### [litemall](https://github.com/linlinjava/litemall1. )
Spring Boot后端 + Vue管理员前端 + 微信小程序用户前端 + Vue用户移动端
