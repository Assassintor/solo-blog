title: MockJs
date: '2019-09-25 12:26:18'
updated: '2019-09-25 12:56:54'
tags: [MockJs, Vue]
permalink: /articles/2019/09/25/1569385578257.html
---

[MockJs](http://mockjs.com/)

[MockJs 文档](https://github.com/nuysoft/Mock/wiki)

[MockJs 示例](http://mockjs.com/examples.html)

![image.png](https://img.hacpai.com/file/2019/09/image-a836ca18.png)

>生成随机数据，拦截 Ajax 请求。

通过随机数据，模拟各种场景；不需要修改既有代码，就可以拦截 Ajax 请求，返回模拟的响应数据；支持生成随机的文本、数字、布尔值、日期、邮箱、链接、图片、颜色等；支持支持扩展更多数据类型，支持自定义函数和正则。

>优点是非常简单方便, 无侵入性, 基本覆盖常用的接口数据类型.
![image.png](https://img.hacpai.com/file/2019/09/image-19d82068.png)

