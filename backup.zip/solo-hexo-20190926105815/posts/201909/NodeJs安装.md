title: NodeJs安装
date: '2019-09-23 15:05:13'
updated: '2019-09-24 12:33:03'
tags: [NodeJs]
permalink: /articles/2019/09/23/1569222313059.html
---
官网下载zip文件包
>官网：[http://nodejs.cn/download/](http://nodejs.cn/download/)

![image.png](https://img.hacpai.com/file/2019/09/image-41f9b6be.png)

下载好后解压

进入解压后的根目录
新建两个目录
>node-global :npm全局安装位置
node-cache：npm 缓存路径

![image.png](https://img.hacpai.com/file/2019/09/image-3909d180.png)

>将node.exe 所在的目录添加到path环境变量，这样我们在使用命令行时就可以在任意路径使用node命令了，同时该目录下有一个npm.cmd文件，打开文件其实就i是将我们的npm命令映射到node.exe npm-cli.js，由于存在该映射所以只要把node.exe 所在的目录添加到path环境变量，也可以在任何目录下执行npm install了。

>D:\node

在命令行中输入如下命令测试
>node -v
>npm -v

那么node-global :npm全局安装位置，node-cache：npm 缓存路径 又是怎么与npm发生关系呢？

通过如下命令进行配置：

>npm config set prefix "D:\node\node_global"  
npm config set cache "D:\node\node_cache"

执行npm命令进行测试：
>npm install webpack -g

会发现node-global下`node_modules`中多了webpack 文件夹

>webpack是用来打包的module，通常我们会在命令行中执行，而webpack同样在`node_global`中做了映射，所以只需要将`node_global`加入path环境变量即可。

>D:\node\node_global\node_modules
