title: Idea一些基本设置
date: '2019-11-09 00:16:07'
updated: '2019-11-09 01:04:56'
tags: [Idea, Idea设置]
permalink: /articles/2019/11/09/1573229767353.html
---
## **IntelliJ IDEA**

如果说IntelliJ IDEA是一款现代化智能开发工具的话，Eclipse则称得上是石器时代的东西了。

其实笔者也是一枚从Eclipse转IDEA的探索者，随着近期的不断开发实践和调试，逐步体会到这款智能IDE带来的巨大开发便利，在强大的插件功能支持下，诸如对Git和Maven的支持简直让人停不下来，各种代码提示，包括JS更是手到擒来，最终不得不被这款神奇的IDE所折服。为了让身边更多的小伙伴参与进来，决定写下这篇文章。

## IDEA VS Eclipse 核心术语比较

由下图可见：两者最大的转变就在于工作空间概念的转变，并且在IDEA当中，Project和 Module是作为两个不同的概念，对项目结构是具有重大意义的，这也恰恰是许多IDEA初学者觉得困扰的地方。

## 为什么要取消工作空间？

答：简单来说，IDEA不需要设置工作空间，因为每一个Project都具备一个工作空间！！对于每一个IDEA的项目工程（Project）而言，它的每一个子模块（Module）都可以使用独立的JDK和MAVEN配置。这对于传统项目迈向新项目的重构添加了极大的便利性，这种多元化的灵活性正是Eclipse所缺失的，因为开始Eclipse在初次使用时已经绑死了工作空间。

## 此外，很多新手都会问，为什么IDEA里面的子工程要称为Module ？

答：其实就是模块化的概念，作为聚合工程亦或普通的根目录，它称之为Project，而下面的子工程称为模块，每一个子模块之间可以相关联，也可以没有任何关联。

## 字体设置
![image.png](https://img.hacpai.com/file/2019/11/image-92402d22.png)

### idea自动提示忽略大小写
![image.png](https://img.hacpai.com/file/2019/11/image-6ab1632b.png)

### idea自动导包
IDEA默认是没有开启自动引包功能的。需要手动打开，位置在：File-->Settings-->Editor-->General-->Auto Import。然后在下图的1和2的位置上进行勾选。

勾选上1的位置后，IDEA 将在我们书写代码的时候自动帮我们优化引入的包，比如自动去掉一些没有用到的包。

勾选上2的位置后，IDEA 将在我们书写代码的时候自动帮我们导入需要用到的包。但是对于那些同名的包，还是需要手动 `Alt + Enter` 进行导入的，IntelliJ IDEA 目前还无法智能到替我们做判断。

![](https://img2018.cnblogs.com/blog/772743/201812/772743-20181225222419341-488060697.png)
 
### idea鼠标悬浮提示
有时候在看代码的时候，不清楚一个类具体是干什么的，就会点进去看这个类的注释，但是强大的IDEA是支持不用点进去就可以看到注释的以及类的相关信息的。但是需要手动打开。具体位置在：File-->Settings-->Editor-->General。然后在下图所示的位置上进行勾选，后面的时间是悬浮提示的显示时间。
![image.png](https://img.hacpai.com/file/2019/11/image-f80ec86e.png)

### Maven 设置
IDEA不像Eclipse那样可以在一个窗口中打开多个项目，IDEA每次打开一个新的项目都需要开一个新的窗口或者覆盖掉当前窗口，所以在打开多个项目的时候就需要开多个窗口，但是如果不设置好默认设置，每次打开一个新的窗口就要重新设置。例如：每次打开新的项目的时候maven的本地仓库地址都要重新设置。通过设置Other Settings就可以解决这类问题。File-->Other Settings-->Preferences for New Projects。然后在左上角的搜索框中搜maven，就能看到如下图所示配置了。

 ![](https://img2018.cnblogs.com/blog/772743/201812/772743-20181225215755670-969534675.png)
### SDK设置
配置默认打开的项目的JDK也和这个类似，File-->Other Settings-->Structure for New Projects。然后就可以看到项目配置（Project Settings）和平台配置(Platform Settings)了。

### 自动编译开关
在IDEA当中自动编译是需要手动打开的，File-->settings-->Build,Execution,Deployment-->Compiler，然后将下图红框处勾上。

![](https://img2018.cnblogs.com/blog/772743/201812/772743-20181225221427509-18512067.png)

### Idea项目 窗口设置
1. Idea避免每次打开idea的时候访问上次最后关闭的项目，其次可以避免刚打开idea的时候加载太多资源
2. IDEA以新窗口的形式打开多个项目
![image.png](https://img.hacpai.com/file/2019/11/image-789b6491.png)

### 解决tomcat中文乱码问题

JAVA_TOOL_OPTIONS -Dfile.encoding=UTF-8

![image.png](https://img.hacpai.com/file/2019/11/image-0ea23189.png)
![image.png](https://img.hacpai.com/file/2019/11/image-da8dacef.png)

### **同时引入多个文件方法时，文件路径会转换成*号**

Setting--editor--code sytle--java--imports  
把Class count to...和Names count to...后边的数值调大一点。
![image.png](https://img.hacpai.com/file/2019/11/image-42fee725.png)



### 内存使用量展示

由于日常开发时都是在公司的办公电脑上进行的，所以内存总是不够用，但是又不清楚IDEA具体实时的占用了多少内存。这个时候对于一些内存并不是太够的开发人员来说能看到实时的内存使用量还是比较好的。IDEA是提供这项功能的，但是需要手动的打开。具体位置在：File-->Settings-->Apperance-->Window Options-->Show Memory indicator。

勾选上后在IDEA的右下角就可以看到实时的内存使用量了，如下图所示：

![image.png](https://img.hacpai.com/file/2019/11/image-0f5d5d71.png)
### Ctrl+鼠标滚轴修改字体大小

IDEA也支持向浏览器那样按住Ctrl+鼠标滚轴来改变编辑区的字体的大小，设置的开关在：File-->Settings-->Editor-->General。

将如下图所示的位置勾选上。
![image.png](https://img.hacpai.com/file/2019/11/image-fdbdb682.png)

### 显示多行Tab

当我们打开的标签页多了的时候，默认的会隐藏在右侧，当我们需要的时候在右侧找到后再打开。IDEA是支持多行显示的，这样在大屏幕的显示器上也不用总去点击右侧的去找刚才打开过的文件了（其实通过Ctril+E也可以找到刚才打开过的文件）。具体开关位置在：File-->Settings-->Editor-->General-->Editor Tabs。

下图位置1的把勾选去掉就可以了。位置2是设置最多展示多少个Tab。
![image.png](https://img.hacpai.com/file/2019/11/image-3a41c249.png)

### 显示行号，显示svn/git最近提交人

在编辑区直接操作，能看到每一行代码的最近一次修改人，以及提交记录信息。这样每行代码都有记录。能很快定位到谁动过代码，然后找到指定的人来解决问题。

### 查看文件的本地历史记录

鼠标选中文件，然后右键，在弹出的列表中选择Local History然后就可以看到文件的本地修改记录，即使没有版本控制工具也可以看到这些记录。

### **IDEA统一编辑文件编码**

全局编码设置  
File -> Other Settings -> Default Settings
Editor -> File Encodings

### **当idea中properties配置文件中文显示utf8编码乱码**

file->setting->editor->file encodings

把transparent native-to-ascll conversion勾选上就行了


### Intellij idea用快捷键自动生成序列化id

Intellij idea用快捷键自动生成序列化id
类继承了Serializable接口之后，使用alt+enter快捷键自动创建序列化id 
进入setting→inspections→serialization issues→选择图中的选项。serializable class without ‘serialVersionUID’ 

![image.png](https://img.hacpai.com/file/2019/11/image-f3f5f5fb.png)


### **设置统一编译器和编译版本**

推荐使用Javac编译器

![image.png](https://img.hacpai.com/file/2019/11/image-5ab97c18.png)

### **设置类注释文件**
![image.png](https://img.hacpai.com/file/2019/11/image-1cbb88b6.png)

### 给选中内容添加双引号“”或单引号''

Settings - Editor - General - Smart Keys - 选中 Surround selection on typing quote or brace

使用方法：

选中要添加双引号的代码 然后按键盘上的双引号（shift+"）即可

扩展：

设置之后也可以直接在选中内容两边加上《》，[]，{}等，使用方法类似。选中代码之后，点<、{、[












