title: CentOS 7.7 发布，作为CentOS 8.0之前的最后一站
date: '2019-09-25 22:13:19'
updated: '2019-09-27 17:26:49'
tags: [Centos8, Centos7]
permalink: /articles/2019/09/25/1569420798963.html
---
首先告诉大家的是[CentOS](https://www.linuxidc.com/topicnews.aspx?tid=14 "CentOS") 8.0将于下周推出，这是期待已久的[Red Hat](https://www.linuxidc.com/topicnews.aspx?tid=10 "Red Hat") Enterprise Linux 8.0社区重建计划。 但对于目前使用CentOS 7/EL7的用户来说，CentOS 7.7已经于今天推出，这是CentOS 7.x系列的增量更新。

![CentOS 7.6下源码安装Emacs 26.3](https://www.linuxidc.com/upload/2019_09/19090108315863.png)

CentOS 8.x系列将基于最近发布的Red Hat Enterprise Linux 8操作系统，并将于下个星期发布，但CentOS 7.x系列已更新至1908版，基于Red Hat Enterprise Linux 7.7源代码的增量更新。

CentOS Linux 7.7（1908）版本的亮点包括默认的[Python](https://www.linuxidc.com/topicnews.aspx?tid=17 "Python") 3.6解释器，BIND 9.11作为默认域名系统软件，Chrony 3.4作为默认的网络时间协议实现，Anaconda中改进的安全配置文件，改进的bug报告，以及来自上游的所有重要安全和包更新。

“所有架构都发布了自上游版本发布的更新。我们强烈建议每个用户通过运行'yum update'在现有的CentOS Linux 7机器上应用所有更新，包括今天发布的内容，”项目负责人Johnny Hughes在发布公告中说。

CentOS Linux 7.7（1908）版本现在可供所有支持的平台下载，包括32位（i386），64位（x86_64），AArch64（ARM64），ARMhfp，PPC64（PowerPC 64位），PPC64le（ PowerPC 64位Little Endian）和IBM POWER9。建议所有用户尽快将其安装更新到新版本。

CentOS Linux是一个滚动发布操作系统意味着您只需安装一次并永久接收更新。因此，建议CentOS Linux 7.7（1908）ISO映像主要用于操作系统的新部署而不是升级，但如果需要重新安装，则必须下载最新和最新的映像。​

有关CentOS 7.7（1908）的更多详情，请参阅其[发布公告](https://lists.centos.org/pipermail/centos-announce/2019-September/023405.html)。 除了x86_64之外，CentOS 7.7 1908还可用于[armhp，aarch64，i386，ppc64，ppc64le和POWER9](https://lists.centos.org/pipermail/centos-announce/2019-September/023406.html)。

[下载](https://centos.org/download/) : [CentOS-7-x86_64-DVD-1810.iso](http://isoredirect.centos.org/centos/7/isos/x86_64/CentOS-7-x86_64-DVD-1810.iso) (4,448MB, [SHA256](http://centos.mirror.rafal.ca/7.7.1908/isos/x86_64/sha256sum.txt), [signature](http://mirror.its.sfu.ca/mirror/CentOS/7.7.1908/isos/x86_64/sha256sum.txt.asc), [torrent](http://mirror.its.sfu.ca/mirror/CentOS/7.7.1908/isos/x86_64/CentOS-7-x86_64-DVD-1908.torrent)), [CentOS-7-x86_64-Minimal-1908.iso](http://centos.mirror.ndchost.com/7.7.1908/isos/x86_64/CentOS-7-x86_64-Minimal-1908.iso) (942MB, [SHA256](http://centos.mirror.ndchost.com/7.7.1908/isos/x86_64/sha256sum.txt), [signature](http://centos.mirror.ndchost.com/7.7.1908/isos/x86_64/sha256sum.txt.asc), [torrent](http://centos.mirror.vexxhost.com/7.7.1908/isos/x86_64/CentOS-7-x86_64-Minimal-1908.torrent))。

更多CentOS相关信息见[CentOS](https://www.linuxidc.com/topicnews.aspx?tid=14) 专题页面 [https://www.linuxidc.com/topicnews.aspx?tid=14](https://www.linuxidc.com/topicnews.aspx?tid=14 "CentOS")

Linux公社的RSS地址：[https://www.linuxidc.com/rssFeed.aspx](https://www.linuxidc.com/rssFeed.aspx)

**原文地址**：[https://www.linuxidc.com/Linux/2019-09/160701.htm](https://www.linuxidc.com/Linux/2019-09/160701.htm)
