title: axios,ajax和fetch的比较
date: '2019-09-25 22:49:37'
updated: '2019-09-27 17:27:09'
tags: [ajax, axios, fetch]
permalink: /articles/2019/09/25/1569422977695.html
---

# [axios, ajax和fetch的比较](http://www.axios-js.com/zh-cn/axios-ajax-fetch-compare.html)

# [](http://www.axios-js.com/zh-cn/blogs/#Ajax "Ajax")Ajax[](http://www.axios-js.com/zh-cn/blogs/#Ajax)

前端程序员常说的Ajax是 `Asynchronous JavaScript and XML`的缩写，意思是异步网络请求。区别于传统web开发中采用的同步方式。

Ajax带来的最大影响就是页面可以无刷新的请求数据。以往，页面表单提交数据，在用户点击完”submit“按钮后，页面会强制刷新一下，体验十分不友好。

传统web请求方式：  
![](https://res.cloudinary.com/dq9x329zv/image/upload/v1552706775/axios-js.com/15527067382726.jpg)

使用Ajax后请求：  
![](https://res.cloudinary.com/dq9x329zv/image/upload/v1552708201/axios-js.com/Snip20190316_17.png)

## [](http://www.axios-js.com/zh-cn/blogs/#%E5%AE%9E%E7%8E%B0%E4%B8%80%E4%B8%AAAjax%E8%AF%B7%E6%B1%82 "实现一个Ajax请求")实现一个Ajax请求

在现代浏览器上实现一个Ajax请求是非常容易的，

```
var request = new XMLHttpRequest(); // 创建XMLHttpRequest对象  
  
//ajax是异步的，设置回调函数  
request.onreadystatechange = function () { // 状态发生变化时，函数被回调  
 if (request.readyState === 4) { // 成功完成  
 // 判断响应状态码  
 if (request.status === 200) {  
 // 成功，通过responseText拿到响应的文本:  
 return success(request.responseText);  
 } else {  
 // 失败，根据响应码判断失败原因:  
 return fail(request.status);  
 }  
 } else {  
 // HTTP请求还在继续...  
 }  
}  
  
// 发送请求:  
request.open('GET', '/api/categories');  
request.setRequestHeader("Content-Type", "application/json") //设置请求头  
request.send();//到这一步，请求才正式发出  
```

使用原生的js还是比较繁琐，实际工程中建议使用jQuery之类的库，封装的ajax请求方法非常好用，且解决了浏览器兼容性的问题。

# [](http://www.axios-js.com/zh-cn/blogs/#axios "axios")axios

首先需要知道：axios不是一种新的技术。

axios 是一个基于Promise 用于浏览器和 nodejs 的 HTTP 客户端，本质上也是对原生XHR的封装，只不过它是Promise的实现版本，符合最新的ES规范，有以下特点：

* 从浏览器中创建 XMLHttpRequests
* 从 node.js 创建 http 请求
* 支持 Promise API
* 拦截请求和响应
* 转换请求数据和响应数据
* 取消请求
* 自动转换 JSON 数据
* 客户端支持防御 XSRF

## [](http://www.axios-js.com/zh-cn/blogs/#%E6%B5%8F%E8%A7%88%E5%99%A8%E6%94%AF%E6%8C%81 "浏览器支持")浏览器支持

![](https://res.cloudinary.com/dq9x329zv/image/upload/v1552717535/axios-js.com/Snip20190316_18.png)

axios面向现代浏览器设计，所以古老的浏览器并不支持。

因为axios设计简洁，API简单，支持浏览器和node，所以大受欢迎。它能很好的与各种前端框架整合。

# [](http://www.axios-js.com/zh-cn/blogs/#fetch "fetch")fetch

fetch是前端发展的一种新技术产物。

以下内容摘自mozilla：  
Fetch API 提供了一个 JavaScript接口，用于访问和操纵HTTP管道的部分，例如请求和响应。它还提供了一个全局 fetch()方法，该方法提供了一种简单，合理的方式来跨网络异步获取资源。

这种功能以前是使用 XMLHttpRequest实现的。Fetch提供了一个更好的替代方法，可以很容易地被其他技术使用，例如 Service Workers。Fetch还提供了单个逻辑位置来定义其他HTTP相关概念，例如CORS和HTTP的扩展。

在使用fetch的时候需要注意：

* 当接收到一个代表错误的 HTTP 状态码时，从 fetch()返回的 Promise 不会被标记为 reject， 即使该 HTTP 响应的状态码是 404 或 500。相反，它会将 Promise 状态标记为 resolve （但是会将 resolve 的返回值的 ok 属性设置为 false ），仅当网络故障时或请求被阻止时，才会标记为 reject。
* 默认情况下，fetch 不会从服务端发送或接收任何 cookies, 如果站点依赖于用户 session，则会导致未经认证的请求（要发送 cookies，必须设置 credentials 选项）。

一个使用fetch获取数据的例子

```
fetch('http://example.com/movies.json')  
 .then(function(response) {  
 return response.json();  
 })  
 .then(function(myJson) {  
 console.log(myJson);  
 });  
```

fetch代表着更先进的技术方向，但是目前兼容性不是很好，在项目中使用的时候得慎重。

