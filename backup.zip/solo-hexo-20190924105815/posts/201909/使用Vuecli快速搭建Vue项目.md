title: 使用Vue-cli快速搭建Vue项目
date: '2019-09-23 15:32:28'
updated: '2019-09-23 15:41:38'
tags: [NodeJs, Npm, Webpack, Vue-cli]
permalink: /articles/2019/09/23/1569223948462.html
---
### [安装NodeJs](https://www.viif.cn/articles/2019/09/23/1569222313059.html)

### 安装cnpm
使用淘宝镜像：
```
npm install -g cnpm --registry=https://registry.npm.taobao.org
```
或者你直接通过添加 `npm` 参数 `alias` 一个新命令:

```bash
alias cnpm="npm --registry=https://registry.npm.taobao.org \
--cache=$HOME/.npm/.cache/cnpm \
--disturl=https://npm.taobao.org/dist \
--userconfig=$HOME/.cnpmrc"

# Or alias it in .bashrc or .zshrc
$ echo '\n#alias for cnpm\nalias cnpm="npm --registry=https://registry.npm.taobao.org \
  --cache=$HOME/.npm/.cache/cnpm \
  --disturl=https://npm.taobao.org/dist \
  --userconfig=$HOME/.cnpmrc"' >> ~/.zshrc && source ~/.zshrc
```
### 安装webpack 
-g代表全局安装
```
npm install -g webpack
```
输入命令`webpack -v`查看是否成功

### 安装`Vue-cli`脚手架（2.0）
```
npm install  -g  vue-cli
```

输入命令`vue -V`查看是否安装成功（注意V是大写）

### 准备阶段
输入如下四个命令
![image.png](https://img.hacpai.com/file/2019/09/image-d1ec582f.png)


安装成功

### 初始化项目
进入我们的工作目录下面，cmd输入命令，初始化项目
```  
vue init webpack  项目名称  
```

```
Project name (admin) 直接回车默认 
Project description (A Vue.js project) 直接回车默认 
Author 直接回车默认 
Install vue-router? Yes （需要，使用路由）
Use ESLint to lint your code? n （不需要，es6的语法，安装后很麻烦，很多批事情，建议不安装）
pick an eslint preset. 默认Standard 
setup unit tests with karma + mocha?No(单元测试不需要) 
setup e2e tests with Nightwatch?No(单元测试不需要)
```

安装好后,进入项目根目录

```
cd 项目名称
```
安装项目依赖：`npm install`


启动项目：`npm run dev`

启动项目后：`localhost:8080`

发布项目：`npm run build`

### [基于`@vue/cli` **3.x** 文档](https://cli.vuejs.org/zh/guide/#%E8%AF%A5%E7%B3%BB%E7%BB%9F%E7%9A%84%E7%BB%84%E4%BB%B6)

### [基于`@vue/cli` **2.x** 文档](https://github.com/vuejs/vue-cli/tree/v2#vue-cli--)
