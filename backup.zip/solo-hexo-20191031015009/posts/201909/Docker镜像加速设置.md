title: Docker 镜像加速设置
date: '2019-09-27 17:19:56'
updated: '2019-09-27 17:20:26'
tags: [Docker]
permalink: /articles/2019/09/27/1569575996589.html
---
>安装了Docker后，为了拉取镜像方便，在阿里云上面申请镜像加速服务。
我申请的地址：`https://bxf4b21y.mirror.aliyuncs.com`

>Docker 在国内的加速地址。
`https://registry.docker-cn.com`

>默认在没用此文件，编辑文件：`vi /etc/docker/daemon.json`
添加如下配置
```
{
  "registry-mirrors": [
        "https://bxf4b21y.mirror.aliyuncs.com",
        "https://registry.docker-cn.com"
        ]
}
```
