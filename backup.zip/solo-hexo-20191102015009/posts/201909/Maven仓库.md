title: Maven仓库
date: '2019-09-23 12:30:56'
updated: '2019-09-24 10:59:00'
tags: [Maven]
permalink: /articles/2019/09/23/1569213055985.html
---
>Maven是一个[项目管理工具]，它包含了一个项目对象模型 (Project Object Model)，一组标准集合，一个项目生命周期(Project Lifecycle)，一个依赖管理系统(Dependency Management System)，和用来运行定义在生命周期阶段(phase)中插件(plugin)目标(goal)的逻辑。


# 为什么要Maven

在开发中经常需要依赖第三方的包，包与包之间存在依赖关系，版本间还有兼容性问题，有时还里要将旧的包升级或降级，当项目复杂到一定程度时包管理变得非常重要。

![](https://images2018.cnblogs.com/blog/63651/201809/63651-20180912151108562-1800188148.png)


Maven是当前最受欢迎的Java项目管理构建自动化综合工具，类似以前Java中的Ant、node.js中的npm、dotNet中的nuget、PHP中的Composer。

Maven这个单词来自于意第绪语（犹太语），意为知识的积累。

![](https://images2018.cnblogs.com/blog/63651/201809/63651-20180910201715315-144666311.png)

>Maven提供了开发人员构建一个完整的生命周期框架。开发团队可以自动完成项目的基础工具建设，Maven使用标准的目录结构和默认构建生命周期。Maven让开发人员的工作更轻松，同时创建报表，检查，构建和测试自动化设置。Maven简化和标准化项目建设过程。处理编译，分配，文档，团队协作和其他任务的无缝连接。 Maven增加可重用性并负责建立相关的任务。

每个Java项目的目录结构都没有一个统一的标准，配置文件到处都是，单元测试代码到底应该放在那里也没有一个权威的规范。

因此，我们就要用到Maven（使用Ant也可以，不过编写Ant的xml脚本比较麻烦）----一个项目管理工具。

Maven主要做了两件事：

>1.统一开发规范与工具
2.统一管理jar包

如果**没有Maven**,你可能不得不经历下面的过程：

>1 如果使用了spring，去spring的官网下载jar包；如果使用hibernate，去hibernate的官网下载Jar包；如果使用Log4j，去log4j的官网下载jar包..... 
2 当某些jar包有依赖的时候，还要去下载对应的依赖jar包 
3 当jar包依赖有冲突时，不得不一个一个的排查 
4 执行构建时，需要使用ant写出很多重复的任务代码 
5 当新人加入开发时，需要拷贝大量的jar包，然后重复进行构建 
6 当进行测试时，需要一个一个的运行....检查

**有了Maven**，它提供了三种功能：

>1 依赖的管理：仅仅通过jar包的几个属性，就能确定唯一的jar包，在指定的文件pom.xml中，只要写入这些依赖属性，就会自动下载并管理jar包。 
2 项目的构建：内置很多的插件与生命周期，支持多种任务，比如校验、编译、测试、打包、部署、发布... 
3 项目的知识管理：管理项目相关的其他内容，比如开发者信息，版本等等 

官网：[http://maven.apache.org/](http://maven.apache.org/)

教程：[https://www.runoob.com/maven/maven-tutorial.html](https://www.runoob.com/maven/maven-tutorial.html)

Maven库：[http://repo2.maven.org/maven2/](http://repo2.maven.org/maven2/) 

中央仓库资源：

[http://mvnrepository.com/](http://mvnrepository.com/)

[https://search.maven.org/](https://search.maven.org/)

# Maven下载和安装
>到Maven官网下载zip文件，解压后安装
![image.png](https://img.hacpai.com/file/2019/09/image-fb73cdcc.png)

### 环境变量配置

>新建环境变量
![image.png](https://img.hacpai.com/file/2019/09/image-5a8f09b9.png)
	
>PATH环境下添加变量
![image.png](https://img.hacpai.com/file/2019/09/image-90376b88.png)	

>进入DOS命令窗口，运行命令  mvn -version，出现如下则配置成功
![image.png](https://img.hacpai.com/file/2019/09/image-fb282089.png)

### 本地仓库设置
> 本地仓库（私有仓库，maven所有的本地jar包都会放在私有仓库里面），其默认位置是当前用户目录下.m2文件夹中。通过修改下面的路径可以修改本地仓库的位置。
![image.png](https://img.hacpai.com/file/2019/09/image-aa9603b4.png)

>远程仓库（中央仓库，配置中央仓库，使用阿里云仓库作为中央仓库的镜像，因为国外的仓库访问非常慢）
![image.png](https://img.hacpai.com/file/2019/09/image-c0fdfd11.png)
````
 <mirror>  
 <id>alimaven</id>  
 <name>aliyun maven</name>  
 <url>http://maven.aliyun.com/nexus/content/groups/public/</url>  
 <mirrorOf>central</mirrorOf>   
 </mirror>
````
